# Change Log

## [1.0.1] 2017-10-31
### Bug fixing
- Variable `$default-color` was changed from `#888888` to `#444`
- ClassName `.navbar-fixed-top` was replaced with `.navbar-fixed`
- Small bug fixes

## [1.0.0] 2017-10-25
### Original Release
- Added React-Bootstrap as base framework
- Added design from Light Bootstrap Dashboard Pro by Creative Tim
